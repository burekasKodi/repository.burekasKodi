# -*- coding: utf-8 -*-
import os
import re
import unicodedata
import json
import zlib
import shutil
import sys

import xbmc
import xbmcvfs
import xbmcaddon
from bs4 import BeautifulSoup

from xbmcplugin import addDirectoryItem
from xbmcgui import ListItem

from http.cookiejar import LWPCookieJar
from urllib.request import Request, build_opener, HTTPCookieProcessor
from urllib.parse import urlencode, quote, quote_plus

##### burekas fix
import PTN
from os import path
from json import loads, load
from time import time

__addon__ = xbmcaddon.Addon()
__version__ = __addon__.getAddonInfo('version')  # Module version
__scriptname__ = __addon__.getAddonInfo('name')
__language__ = __addon__.getLocalizedString
__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__temp__ = xbmcvfs.translatePath(os.path.join(__profile__, 'temp', ''))
__subsFolder__ = xbmcvfs.translatePath(os.path.join(__temp__, 'subs', ''))
__kodi_version__ = xbmc.getInfoLabel('System.BuildVersion').split(' ')[0]
__scriptid__ = __addon__.getAddonInfo('id')

regexHelper = re.compile('\W+', re.UNICODE)


# ===============================================================================
# Private utility functions
# ===============================================================================
def normalizeString(_str):
    if not isinstance(_str, str):
        _str = unicodedata.normalize('NFKD', _str)  # .encode('utf-8', 'ignore')
    return _str


def clean_title(text):
    try:
        log("clean_title - before: " + repr(text))

        temp=re.sub("([\(\[]).*?([\)\]])", "\g<1>\g<2>", text)

        temp=temp.replace("(","")
        temp=temp.replace(")","")
        temp=temp.replace("[","")
        temp=temp.replace("]","")
        temp=temp.replace("1080 HD","")
        temp=temp.replace("720 HD","")

        if "  - " in temp:
            temp=temp.split("  - ")[0]

        title = path.splitext(temp)

        if len(title) > 1:
            if re.match(r'^\.[a-z]{2,4}$', title[1], re.IGNORECASE):
                text = title[0]
            else:
                text = ''.join(title)
        else:
            text = title[0]

        #text = str(text) #unicode(text, "utf-8")		# burekas fix - offline hebrew titles

        # Removes country identifier at the end
        text = re.sub(r'\([^\)]+\)\W*$', '', text).strip()

        log("clean_title - after: " + repr(text))
        return text

    except Exception as e:
        log("clean_title Error: " + repr(e))

def clean_titles(item):
    try:
        if 'title' in item:
            log("clean_title [title]")
            item['title'] = clean_title(item['title'])
        if 'tvshow' in item:
            log("clean_title [tvshow]")
            item['tvshow'] = clean_title(item['tvshow'])
    except Exception as e:
        log("clean_titles Error: " + repr(e))


def parse_rls_title(item): ##### burekas
    title = re.sub(r'\([^\)]+\)\W*$', '', item['title']).strip()
    tvshow = re.sub(r'\([^\)]+\)\W*$', '', item['tvshow']).strip()

    groups = re.findall(r"(.*?) (\d{4})? ?(?:s|season|)(\d{1,2})(?:e|episode|x|\n)(\d{1,2})", title, re.I)

    if len(groups) == 0:
        groups = re.findall(r"(.*?) (\d{4})? ?(?:s|season|)(\d{1,2})(?:e|episode|x|\n)(\d{1,2})", tvshow, re.I)

    if len(groups) > 0 and len(groups[0]) >= 3:
        title, year, season, episode = groups[0]
        item["year"] = str(int(year)) if len(year) == 4 else year

        item["tvshow"] = re.sub(r'\([^\)]+\)\W*$', '', title).strip()
        item["season"] = str(int(season))
        item["episode"] = str(int(episode))
        log("TV Parsed Item: %s" % (item,))

    else:  # For cases such a movie: "1917"
        groups = re.findall(r"(.*?)(\d{4})", item["title"], re.I)
        if len(groups) > 0 and len(groups[0]) >= 1:
            if len(groups[0][0]) >= 1:
                title = groups[0][0]
                item["title"] = re.sub(r'\([^\)]+\)\W*$', '', title).strip()
                item["year"] = groups[0][1] if len(groups[0]) == 2 else item["year"]

                log("MOVIE Parsed Item: %s" % (item,))
            elif len(groups[0][1]) >= 1:
                title = groups[0][1]
                item["title"] = re.sub(r'\([^\)]+\)\W*$', '', title).strip()
                item["year"] = groups[1][1] if len(groups[1]) == 2 else item["year"]

                log("MOVIE Parsed Item: %s" % (item,))

def prepare_video_filename(filename):
    from urllib.parse import unquote

    clean_filename = unquote(filename)
    clean_filename = clean_filename.split("?")
    clean_filename = path.basename(clean_filename[0])[:-4]
    return clean_filename

def log(msg):
    xbmc.log("### [%s] - %s" % (__scriptname__, msg), level=xbmc.LOGDEBUG)


def notify(msg_id):
    xbmc.executebuiltin((u'Notification(%s,%s)' % (__scriptname__, __language__(msg_id))))


class SubsHelper:
    BASE_URL = "https://www.ktuvit.me/Services"

    def __init__(self):
        self.urlHandler = URLHandler()

    def get_subtitle_list(self, item):
        search_results = self._search(item)
        # results = self._build_subtitle_list(search_results, item)

        self.arrange_subs_results(item, search_results)

        # return results

    # return list of movies / tv-series from the site`s search
    def _search(self, item):
        search_string = re.split(r'\s\(\w+\)$', item["tvshow"])[0] if item["tvshow"] else item["title"]
        withSubsOnly = False if item["tvshow"] else True
        log("search_string: %s" % search_string)

        query = {"FilmName": search_string,
                 "Actors": [],
                 "Studios": None,
                 "Directors": [],
                 "Genres": [],
                 "Countries": [],
                 "Languages": [],
                 "Year": "",
                 "Rating": [],
                 "Page": 1,
                 "SearchType": "0",
                 "WithSubsOnly": withSubsOnly}
        if item["tvshow"]:
            query["SearchType"] = "1"
        # optional: filtering by 'year'
        # elif item["year"] and not item["tvshow"]:
        #     query["Year"] = item["year"]

        search_result = self.urlHandler.request(self.BASE_URL + "/ContentProvider.svc/SearchPage_search",
                                                data={"request": query})

        results = []
        log("Results: %s" % search_result)

        if search_result is None or len(search_result["Films"]) == 0:
            #notify(32001)
            return results  # return empty set

        ids = self._get_filtered_ids(search_result["Films"], search_string, item)  ##### burekas
        log("Filtered Ids: %s" % ids)

        if item["tvshow"]:
            results = self._search_tvshow(item, ids)
        else:
            results = self._search_movie(ids)

        log("Subtitles: %s" % results)

        return results

    def _search_tvshow(self, item, ids):
        subs = []

        for id in ids:
            query_string = {
                "moduleName": "SubtitlesList",
                "SeriesID": id,
                "Season": item['season'],
                "Episode": item['episode']
            }
            raw_html = self.urlHandler.request(self.BASE_URL + "/GetModuleAjax.ashx", query_string=query_string)

            sub_list = BeautifulSoup(raw_html, "html.parser")
            sub_rows = sub_list.find_all("tr")

            for row in sub_rows:
                columns = row.find_all("td")
                sub = {
                    'id': id
                }
                for index, column in enumerate(columns):
                    if index == 0:
                        sub['rls'] = column.get_text().strip().split("\n")[0]
                    if index == 4:
                        sub['downloads'] = int(column.get_text().strip())
                    if index == 5:
                        sub['sub_id'] = column.find("input", attrs={"data-sub-id": True})["data-sub-id"]

                if (sub['rls'] != 'אין כתוביות'): ###### burekas fix (Sometimes a strange result returns as 'אין כתוביות')
                    subs.append(sub)

        return subs

    def _search_movie(self, ids):
        subs = []

        for movie_id in ids:
            query_string = {
                "ID": movie_id,
            }
            raw_html = self.urlHandler.request(self.BASE_URL + "/../MovieInfo.aspx", query_string=query_string)
            html = BeautifulSoup(raw_html, "html.parser")
            sub_rows = html.select("table#subtitlesList tbody > tr")
            #log('html %s' % sub_rows)

            for row in sub_rows:
                columns = row.find_all("td")
                sub = {
                    'id': movie_id
                }
                for index, column in enumerate(columns):
                    if index == 0:
                        sub['rls'] = column.get_text().strip().split("\n")[0]
                    if index == 4:
                        sub['downloads'] = int(column.get_text().strip())
                    if index == 5:
                        sub['sub_id'] = column.find("a", attrs={"data-subtitle-id": True})["data-subtitle-id"]

                if (sub['rls'] != 'אין כתוביות'): ###### burekas fix (Sometimes a strange result returns as 'אין כתוביות')
                    subs.append(sub)

        return subs

    def build_subs_list_with_percentage(self, json, item):
        subs = []

        array_original = self.orginaize_video_filename_for_compare(item['file_original_path'], 1)
        array_original2 = self.orginaize_video_filename_for_compare(xbmc.getInfoLabel("VideoPlayer.title"), 2)

        if json != 0:
            check_sub_sync = self.is_to_check_percent(item)

            for item_data in json:
                sub = {}
                sub['title'] = item_data["rls"]
                sub['id'] = item_data["id"]
                sub['sub_id'] = item_data["sub_id"]

                if check_sub_sync:
                    percent = self.calc_sub_percent_sync(sub['title'], array_original) if len(array_original) > 1 else 0
                    percent2 = self.calc_sub_percent_sync(sub['title'], array_original2) if len(array_original2) > 1 else 0

                    if percent2 > percent:
                        percent = percent2

                    sub['percent'] = percent
                    sub['score'] = str(round(float(percent / 20)))
                    sub['sub_percent'] = str(percent) + "% | "
                    sub['synced'] = "true" if percent > 80 else "false"
                else:
                    percent = 0
                    sub['percent'] = percent
                    sub['score'] = ''
                    sub['sub_percent'] = ''
                    sub['synced'] = "false"

                subs.append(sub)

            # Sort list by sync percentages
            subs = sorted(subs, key=lambda x: x['percent'], reverse=True)

        return subs

    def generate_subs_results_list(self, subs):
        for x in subs:
            listitem = ListItem(label="Hebrew",
                                label2=str(x['sub_percent'] + x['title']))
            listitem.setArt({'icon' : x['score'], 'thumb': 'he'})
            listitem.setProperty("sync", x['synced'])
            url = "plugin://%s/?action=download&id=%s&sub_id=%s&filename=%s&language=%s" % (
                __scriptid__, x["id"], x["sub_id"], x["title"], 'he')

            addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=False)


    def arrange_subs_results(self, item, json):
        if json != 0:
            subs = self.build_subs_list_with_percentage(json, item)
            self.generate_subs_results_list(subs)


    def is_to_check_percent(self, item):
        # Check % only when player is playing
        # or not playing and library based on local file:
        # Without 'strm' which is video addon file or 'plugin://' which is video addon menu
        # Or not Manual Search
        return ((xbmc.Player().isPlaying()
                or (not xbmc.Player().isPlaying()
                    and (not any(s in item['full_path'] for s in ['strm','plugin://']))))
                and ('manual_search' in item and item['manual_search'] == False))

    def orginaize_video_filename_for_compare(self, _text, _index):
        text = self.remove_brackets_content_from_text(_text)
        text = self.replace_chars_from_text(text)
        text = (text.replace(".avi","").replace(".mp4","").replace(".mkv",""))
        log("Video source %s for compare: %s" %(_index, text))

        _array = (text.split("."))
        log("Video source %s for compare (array): %s" %(_index, _array))

        return _array

    def remove_brackets_content_from_text(self, text):
        # # Count the number of bracket pairs in the text
        # bracket_count = text.count('[')
        # # If there are more than one pair of brackets, remove the last pair and their content
        # if bracket_count > 1:

        # Find the last occurrence of '[' and ']'
        last_open_bracket = text.rfind('[')
        last_close_bracket = text.rfind(']')

        if last_open_bracket != -1 and last_close_bracket != -1 and last_open_bracket < last_close_bracket:
            # Remove the last set of brackets and their content
            text = text[:last_open_bracket] + text[last_close_bracket + 1:]

        return text

    def replace_chars_from_text(self, _text):
        text = (_text.strip()
            .replace("_",".").replace(" ",".")
            .replace("/",".")
            .replace(":","")
            .replace("-",".").replace("+",".")
            .replace("[",".").replace("]",".")
            .replace("(",".").replace(")","."))

        return text

    def calc_sub_percent_sync(self, sub_filename, array_original):
        try:
            #json_value is the subtitle filename
            #array_original is the video/source filename

            release_names = ['bluray','blu-ray','bdrip','brrip','brip',
                        'hdtv','hdtvrip','pdtv','tvrip','hdrip','hd-rip','hc',
                        'web','web-dl','web dl','web-dlrip','webrip','web-rip',
                        'dvdr','dvd-r','dvd-rip','dvdrip','cam','hdcam','cam-rip',
                        'screener','dvdscr','dvd-full',
                        'tc','telecine','ts','hdts','telesync']

            resolutions = ['720p','1080p','1440p','2160p','2k','4320p','4k']

            quality=xbmc.getInfoLabel("VideoPlayer.VideoResolution")+'p'

            text = sub_filename

            text = self.replace_chars_from_text(text)
            text = (text.replace(".srt",''))
            # text = remove_brackets_content_from_text(text)
            array_subs = (text.split("."))
            ##array_subs.pop(0)

            #remove empty items from sub array
            array_subs = [element.strip().lower() for element in array_subs if element != '']
            #array_subs=[str(x).lower() for x in array_subs if x != '']

            # remove language code if exist
            if array_subs[-1].lower() != 'hi' and len(array_subs[-1]) == 2:
                array_subs.pop(-1)

            # fix for 'Opensubtitles" subs - remove 'cc' addition ('hi', 'no hi') if exist
            if array_subs[-1].lower() == 'hi' and array_subs[-2].lower() == 'no':
                array_subs.pop(-1)
                array_subs.pop(-1)
            #array_subs=[element for element in array_subs if element not in ('hi')] # was ('-','no','hi')

            #log("Video source array before compare: %s" %array_original)
            #log("Subtitle array before compare: %s" %array_subs)

            array_original=[element.strip().lower() for element in array_original if element != '']
            #array_original=[element.strip().lower() for element in array_original]
            #array_original=[str(x).lower() for x in array_original if x != '']

            #----------------------------------------------------------------------------------#
            # 1st priority "release name" (+3 if "release name" are equal)
            # 2nd priority "release type" (+2 if "release name" and "release type" are equal)
            # 3th priority "resolution"   (+1 if "release name" and "release type" and "resolution" are equal)
            #----------------------------------------------------------------------------------#

            # Give "release name" more weight (x3) to the ratio score of the compare
            # 1st priority "release name"
            #log("Video source release: %s" %array_original[-1])
            #log("Subtitle release: %s" %array_subs[-1])
            release_name_position = -2 if array_subs[-1].lower() == 'hi' else -1
            sub_release_name = array_subs[release_name_position]
            video_release_name = array_original[-1]
            if sub_release_name.lower() == video_release_name.lower():
                for i in range(3):
                    array_subs.append(sub_release_name)
                    array_original.append(video_release_name)

                # Give "release type" more weight (x2) to the ratio score of the compare
                # 2nd priority "release type"
                sub_release_type = list(set(array_subs).intersection(release_names))
                video_release_type = list(set(array_original).intersection(release_names))
                if len(sub_release_type) > 0 and len(video_release_type) > 0 and sub_release_type[-1] == video_release_type[-1]:
                    for i in range(2):
                        array_original.append(video_release_type[-1])
                        array_subs.append(sub_release_type[-1])

                    # 3th priority "resolution"
                    video_quality = list(set(array_original).intersection(resolutions))
                    sub_quality = list(set(array_subs).intersection(resolutions))
                    if len(video_quality) > 0 and len(sub_quality) > 0 and sub_quality[-1] == video_quality[-1]:
                        for i in range(1):
                            array_original.append(video_quality[-1])
                            array_subs.append(sub_quality[-1])
                            #log("Video source quality: %s" %repr(video_quality[0]))
                            #log("Subtitle quality: %s" %repr(sub_quality[0]))

            log("Video source array for compare: %s" %array_original)
            log("Subtitle array for compare: %s" %array_subs)
            precent = self.similar(array_original,array_subs)
            return precent

        except Exception as e:
            log("Error in calc_sub_percent_sync: " + repr(e) + " | sub_filename: " + repr(sub_filename))
            return 0

    def similar(self, w1, w2):
        from difflib import SequenceMatcher

        s = SequenceMatcher(None, w1, w2)
        return int(round(s.ratio()*100))

    def _build_subtitle_list(self, search_results, item):
        language = 'en' if item["preferredlanguage"]=='eng' else 'he' #'he'
        lang3 = xbmc.convertLanguage(language, xbmc.ISO_639_2)
        total_downloads = 0
        ret = []
        for result in search_results:
            title = result["rls"]
            subtitle_rate = self._calc_rating(title, item["file_original_path"])
            total_downloads += result['downloads']

            ret.append({
                'lang_index': exec('try:item["3let_language"].index(lang3)\nexcept:0'), #item["3let_language"].index(lang3),
                'filename': title,
                'language_name': xbmc.convertLanguage(language, xbmc.ENGLISH_NAME),
                'language_flag': language,
                'id': result["id"],
                'sub_id': result["sub_id"],
                'rating': result['downloads'],
                'sync': subtitle_rate >= 3.8,
                'hearing_imp': False,
                'is_preferred': lang3 == item['preferredlanguage']
            })

        # Fix the rating
        if total_downloads:
            for it in ret:
                log('rating %s totals %s' % (it['rating'], total_downloads))
                it["rating"] = str(int(round(it["rating"] / float(total_downloads), 1) * 5))

        return sorted(ret, key=lambda x: (x['is_preferred'], x['lang_index'], x['sync'], x['rating']), reverse=True)

    def _calc_rating(self, subsfile, file_original_path):
        file_name = os.path.basename(file_original_path)
        folder_name = os.path.split(os.path.dirname(file_original_path))[-1]

        subsfile = re.sub(r'\W+', '.', subsfile).lower()
        file_name = re.sub(r'\W+', '.', file_name).lower()
        folder_name = re.sub(r'\W+', '.', folder_name).lower()
        log("# Comparing Releases:\n [subtitle-rls] %s \n [filename-rls] %s \n [folder-rls] %s" % (
            subsfile, file_name, folder_name))

        subsfile = subsfile.split('.')
        file_name = file_name.split('.')[:-1]
        folder_name = folder_name.split('.')

        if len(file_name) > len(folder_name):
            diff_file = list(set(file_name) - set(subsfile))
            rating = (1 - (len(diff_file) / float(len(file_name)))) * 5
        else:
            diff_folder = list(set(folder_name) - set(subsfile))
            rating = (1 - (len(diff_folder) / float(len(folder_name)))) * 5

        log("\n rating: %f (by %s)" % (round(rating, 1), "file" if len(file_name) > len(folder_name) else "folder"))

        return round(rating, 1)

    def download(self, id, sub_id, filename):
        ## Cleanup temp dir, we recomend you download/unzip your subs in temp folder and
        ## pass that to XBMC to copy and activate
        if xbmcvfs.exists(__subsFolder__):
            shutil.rmtree(__subsFolder__)
        xbmcvfs.mkdirs(__subsFolder__)

        query = {
            "request": {
                "FilmID": id,
                "SubtitleID": sub_id,
                "FontSize": 0,
                "FontColor": "",
                "PredefinedLayout": -1}}

        response = self.urlHandler.request(self.BASE_URL + "/ContentProvider.svc/RequestSubtitleDownload", data=query)
        f = self.urlHandler.request(self.BASE_URL + '/DownloadFile.ashx',
                                    query_string={"DownloadIdentifier": response["DownloadIdentifier"]})
        with open(filename, "wb") as subFile:
            subFile.write(f)
        subFile.close()

    def login(self, notify_success=False):
        email = __addon__.getSetting("email")
        password = __addon__.getSetting("password")
        post_data = {"request": {"Email": email, "Password": password}}

        response = self.urlHandler.request(self.BASE_URL + "/MembershipService.svc/Login", data=post_data)
        log("Login response is: %s" % (response))

        if response["IsSuccess"] is True:
            self.urlHandler.save_cookie()
            if notify_success:
                notify(32007)
            return True
        else:
            notify(32005)
            return None

    def _get_filtered_ids(self, list, search_string, item):    ##### burekas
        ids = []

        search_string = regexHelper.sub('', search_string).lower()

        #first filtered by imdb
        for result in list:
            if (len(result['ImdbID']) > 2 and result['ImdbID'] in item['imdb_id']):
                ids.append(result["ID"])

        #if ids still empty (wrong imdb on ktuvit page) filtered by text
        if ids == []:
            for result in list:
                eng_name = regexHelper.sub('', regexHelper.sub(' ', result['EngName'])).lower()
                heb_name = regexHelper.sub('', result['HebName'])

                if ((search_string.startswith(eng_name) or eng_name.startswith(search_string) or
                        search_string.startswith(heb_name) or heb_name.startswith(search_string))
                        and (not item["tvshow"] and str(result['ReleaseDate']) == str(item['year']))):
                    ids.append(result["ID"])

        return ids


class URLHandler:
    def __init__(self):
        cookie_filename = os.path.join(__profile__, "cookiejar.txt")
        self.cookie_jar = LWPCookieJar(cookie_filename)
        if os.access(cookie_filename, os.F_OK):
            self.cookie_jar.load()

        self.opener = build_opener(HTTPCookieProcessor(self.cookie_jar))
        self.opener.addheaders = [('Accept-Encoding', 'gzip'),
                                  ('Accept-Language', 'en-us,en;q=0.5'),
                                  ('Pragma', 'no-cache'),
                                  ('Cache-Control', 'no-cache'),
                                  ('Content-type', 'application/json'),
                                  ('User-Agent',
                                   'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Kodi/%s Chrome/78.0.3904.97 Safari/537.36' % (
                                       __kodi_version__))]

    def request(self, url, data=None, query_string=None, referrer=None, cookie=None):
        if data is not None:
            data = json.dumps(data).encode('utf8')
        if query_string is not None:
            url += '?' + urlencode(query_string)
        if referrer is not None:
            self.opener.addheaders += [('Referrer', referrer)]
        if cookie is not None:
            self.opener.addheaders += [('Cookie', cookie)]

        content = None
        log("Getting url: %s" % (url))
        if data is not None:
            log("Post Data: %s" % (data))
        try:
            req = Request(url, data, headers={'Content-Type': 'application/json'})
            response = self.opener.open(req)
            content = None if response.code != 200 else response.read()

            if response.headers.get('content-encoding', '') == 'gzip':
                try:
                    content = zlib.decompress(content, 16 + zlib.MAX_WBITS)
                except zlib.error:
                    pass

            if response.headers.get('content-type', '').startswith('application/json'):
                try:
                    parsed_content = json.loads(content)
                    content = json.loads(parsed_content["d"])
                    log("content (without encoding) is: %s" % (content))
                except:
                    parsed_content = json.loads(content, encoding="utf-8")
                    content = json.loads(parsed_content["d"], encoding="utf-8")
                    log("content (with encoding) is: %s" % (content))

            response.close()
        except Exception as e:
            log("Failed to get url: %s\n%s" % (url, e))
            # Second parameter is the filename
        return content

    def save_cookie(self):
        # extend cookie expiration
        for cookie in self.cookie_jar:
            if cookie.expires is not None:
                cookie.expires += 2 * 12 * 30 * 24 * 60 * 60

        self.cookie_jar.save()

''' ###### burekas
def title_from_focused_item(item_data): ###### burekas
    label_type = xbmc.getInfoLabel("ListItem.DBTYPE")  # movie/tvshow/season/episode
    label_movie_title = xbmc.getInfoLabel("ListItem.OriginalTitle")
    is_movie = xbmc.getCondVisibility("Container.Content(movies)") or label_type == 'movie'
    is_episode = xbmc.getCondVisibility("Container.Content(episodes)") or label_type == 'episode'

    title = ''
    if is_movie and label_movie_title and item_data['year']:
        title = label_movie_title + " " + item_data['year']
    elif is_episode and item_data['tvshow'] and item_data['season'] and item_data['episode']:
        title = ("%s S%.2dE%.2d" % (item_data['tvshow'], int(item_data['season']), int(item_data['episode'])))

    return title
'''

def get_TMDB_data_popularity_and_votes_sorted(url,filename):    ##### burekas
    log("searchTMDB: %s" % url)
    json = caching_json(filename,url)
    json_results = json["results"]
    log("get_TMDB_data_popularity_and_votes_sorted: json_results - " + repr(json_results))
    # 1st priority: popularity
    # 2nd priority: vote_count
    json_results.sort(key = lambda x:(x["popularity"],x["vote_count"]), reverse=True)
    # json_results = sorted(json_results, key = lambda x:(x["popularity"],x["vote_count"]), reverse=True)
    # json_results.sort(key = lambda x:x["popularity"], reverse=True)
    # json_results.sort(key = lambda x:x["vote_count"], reverse=True)
    log("get_TMDB_data_popularity_and_votes_sorted: json_results sorted - " + repr(json_results))

    return json_results

def get_TMDB_data_filtered(url,filename,query,type,year=0):    ##### burekas
    log("searchTMDB: %s" % url)
    log("query filtered: %s" % query)
    json = caching_json(filename,url)
    json_results = json["results"]
    log("get_TMDB_data_filtered: json_results - " + repr(json_results))
    if type=='tv':
        json_results.sort(key = lambda x:x["name"]==query, reverse=True)
    else:
        if int(year) > 0:
            json_results.sort(key = lambda x:(x["title"]==query,str(year) in str(x["release_date"])), reverse=True)
            #json_results.sort(key = lambda x:(x["title"]==query), reverse=True)
        else:
            json_results.sort(key = lambda x:x["title"]==query, reverse=True)
    log("get_TMDB_data_filtered: json_results sorted - " + repr(json_results))

    return json_results

def getTVShowOriginalTitle(source="notPlaying"): ###### burekas
    log("getTVShowOriginalTitle")

    #First, check if database has the original title.
    labelTVShowTitle = getTVshowOriginalTitleByJSONandDBid(source)    ##using kodi database json
    #If not, try get the original title by using tmdb api
    if (labelTVShowTitle == "" or not labelTVShowTitle.isascii()):
        labelTVShowTitle = getTVshowOriginalTitleByTMDBapi(source)  ##New way using tmdb api

    return labelTVShowTitle

def takeTitleFromFocusedItem(type="movie"): ###### burekas
    labelMovieTitle = xbmc.getInfoLabel("ListItem.OriginalTitle")
    labelYear = xbmc.getInfoLabel("ListItem.Year")
    labelTVShowTitle = getTVShowOriginalTitle('notPlaying') #xbmc.getInfoLabel("ListItem.TVShowTitle") #xbmc.getInfoLabel("ListItem.OriginalTitle")
    labelSeason = xbmc.getInfoLabel("ListItem.Season")
    labelEpisode = xbmc.getInfoLabel("ListItem.Episode")
    labelType = xbmc.getInfoLabel("ListItem.DBTYPE")  #movie/tvshow/season/episode
    isItMovie = labelType == 'movie' or xbmc.getCondVisibility("Container.Content(movies)")
    isItEpisode = labelType == 'episode' or xbmc.getCondVisibility("Container.Content(episodes)")
    labelDBID = xbmc.getInfoLabel("ListItem.DBID")

    title = 'SearchFor...'
    if isItMovie and labelMovieTitle and labelYear:
        title = ("%s %s" % (labelMovieTitle, labelYear)) if type == 'movie' else '' ###### burekas
    elif isItEpisode and labelTVShowTitle and labelSeason and labelEpisode:
        title = ("%s S%.2dE%.2d" % (labelTVShowTitle, int(labelSeason), int(labelEpisode))) if type == 'tvshow' else '' ###### burekas

    return title

def getTVshowOriginalTitleByJSONandDBid(source="notPlaying"): ###### burekas
    log("getTVshowOriginalTitleByJSONandDBid")

    try:
        if (source=="notPlaying"):
            labelDBID = xbmc.getInfoLabel("ListItem.DBID")
        else:
            labelDBID = xbmc.getInfoLabel("VideoPlayer.DBID")

        originalShowTitle = ''

        requestEpisodeDetails = {"jsonrpc": "2.0", "id": 1 , "method": "VideoLibrary.GetEpisodeDetails", "params": {"episodeid": int(labelDBID), "properties": ["tvshowid"]}}
        resultsEpisodeDetails = json.loads(xbmc.executeJSONRPC(json.dumps(requestEpisodeDetails)))

        tvshowDBID = resultsEpisodeDetails["result"]["episodedetails"]["tvshowid"]

        requestTVShowDetails = {"jsonrpc": "2.0", "id": 1 , "method": "VideoLibrary.GetTVShowDetails", "params": {"tvshowid": int(tvshowDBID), "properties": ["originaltitle"]}}
        resultsTVShowDetails = json.loads(xbmc.executeJSONRPC(json.dumps(requestTVShowDetails)))

        tvshowOriginalTitle = resultsTVShowDetails["result"]["tvshowdetails"]["originaltitle"]

        originalShowTitle = tvshowOriginalTitle

        return originalShowTitle

    except Exception as err:
        log('Caught Exception: error getTVshowOriginalTitleByJSONandDBid: %s' % format(err))
        #originalShowTitle = ''
        return ''


def getTVshowOriginalTitleByTMDBapi(source="notPlaying"): ###### burekas
    log("getTVshowOriginalTitleByTMDBapi")

    try:
        if (source=="notPlaying"):
            labelTVShowTitle = xbmc.getInfoLabel("ListItem.TVShowTitle")
            labelYear = xbmc.getInfoLabel("ListItem.Year")
        else:
            labelTVShowTitle = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
            labelYear = xbmc.getInfoLabel("VideoPlayer.Year")

        log("getTVshowOriginalTitleByTMDBapi: labelTVShowTitle: %s, year: %s" %(labelTVShowTitle,labelYear))

        if labelTVShowTitle != '' and labelTVShowTitle.isascii():
            return lowercase_with_underscores(labelTVShowTitle)

        originalTitle = ''

        if labelTVShowTitle != '':
            tmdbKey = '653bb8af90162bd98fc7ee32bcbbfb3d'
            filename = 'subs.search.tmdb.%s.%s.%s.json' % ("tv",lowercase_with_underscores(labelTVShowTitle), labelYear)

            # For TV Shows there is no actuall meaning when using the "yeat" param in the url
            if int(labelYear) > 0:
                #url = "http://api.tmdb.org/3/search/%s?api_key=%s&query=%s&year=%s&language=en" % ("tv",tmdbKey, labelTVShowTitle, labelYear)
                url = "http://api.themoviedb.org/3/search/%s?api_key=%s&query=%s&year=%s&language=en" % ("tv",tmdbKey, labelTVShowTitle, labelYear)
            else:
                #url = "http://api.tmdb.org/3/search/%s?api_key=%s&query=%s&language=en" % ("tv",tmdbKey, labelTVShowTitle)
                url = "http://api.themoviedb.org/3/search/%s?api_key=%s&query=%s&language=en" % ("tv",tmdbKey, labelTVShowTitle)

            log( "searchTMDB for original tv title: %s" % url)

            json_results = get_TMDB_data_popularity_and_votes_sorted(url,filename)

            '''
            json = caching_json(filename,url)

            resultsLen = len(json["results"])
            itemIndex = -1
            voteCountMax = 0
            popularityMax = 0
            itemIndexMax = 0
            for item in json['results']:
                itemIndex += 1
                if (item['vote_count'] > voteCountMax and item['popularity'] > popularityMax):
                    voteCountMax = item['vote_count']
                    popularityMax = item['popularity']
                    itemIndexMax = itemIndex

            if resultsLen > 0 :
                #originalTitle = json["results"][itemIndexMax]["original_name"]
                originalTitle = json["results"][itemIndexMax]["name"]
            '''

            try:    originalTitle = json_results[0]["name"]
            except Exception as e:
                log( "getTVshowOriginalTitleByTMDBapi originalTitle Error [%s]" % (e,))
                return ''

        log("getTVshowOriginalTitleByTMDBapi - title: " + originalTitle)
        return originalTitle
    except Exception as err:
        log('Caught Exception: error searchTMDB: %s' % format(err))
        #originalTitle = ''
        return ''

def caching_json(filename, url):   ####### burekas
    from requests import get

    if (__addon__.getSetting( "json_cache" ) == "true"):
        json_file = path.join(__temp__, filename)
        if not path.exists(json_file) or not path.getsize(json_file) > 20 or (time()-path.getmtime(json_file) > 30*60):
            data = get(url, verify=False)
            open(json_file, 'wb').write(data.content)
        if path.exists(json_file) and path.getsize(json_file) > 20:
            with open(json_file,'r',encoding='utf-8') as json_data:
                json_object = load(json_data)
            return json_object
        else:
            return 0

    else:
        try:
          json_object = get(url).json()
        except:
          json_object = {}
          pass
        return json_object

def checkAndParseIfTitleIsTVshowEpisode(manualTitle):
    try:
        pattern = re.compile(r"%20|_|-|\+|\.")
        replaceWith = " "
        manualTitle = re.sub(pattern, replaceWith, manualTitle)

        matchShow = re.search(r'(?i)^(.*?)\sS\d', manualTitle)
        if matchShow == None:
            return ["NotTVShowEpisode", "0", "0",'']
        else:
            tempShow = matchShow.group(1)

        matchSnum = re.search(r'(?i)%s(.*?)E' %(tempShow+" s"), manualTitle)
        if matchSnum == None:
            return ["NotTVShowEpisode", "0", "0",'']
        else:
            tempSnum = matchSnum.group(1)

        matchEnum = re.search(r'(?i)%s(.*?)$' %(tempShow+" s"+tempSnum+"e"), manualTitle)
        if matchEnum == None:
            return ["NotTVShowEpisode", "0", "0",'']
        else:
            tempEnum = matchEnum.group(1)

        return [tempShow, tempSnum, tempEnum, 'episode']

    except Exception as err:
        log( "checkAndParseIfTitleIsTVshowEpisode error: '%s'" % err)
        return ["NotTVShowEpisode", "0", "0",'']

def is_local_file_tvshow(item):
    return item["title"] and (int(item["year"])==0) # or "smb:" in item['full_path'])

def searchForIMDBID(query,item):  ##### burekas
    log("searchForIMDBID")
    log("searchForIMDBID - item: " + repr(item))
    log("searchForIMDBID - query: " + repr(query))

    tmdbKey = '653bb8af90162bd98fc7ee32bcbbfb3d'

    info=(PTN.parse(query))

    if ((item["tvshow"] and item['dbtype'] == 'episode') or is_local_file_tvshow(item)):
        type_search='tv'
        temp_query = item["tvshow"]
        year = 0 #year = item["year"]
        url="https://api.tmdb.org/3/search/%s?api_key=%s&query=%s&language=en&append_to_response=external_ids"%(type_search,tmdbKey,quote_plus(temp_query))
        #url="https://api.tmdb.org/3/search/tv?api_key=%s&query=%s&year=%s&language=he&append_to_response=external_ids"%(tmdbKey,quote_plus(temp_query),year)
        #url='https://www.omdbapi.com/?apikey=8e4dcdac&t=%s&year=%s'%(temp_query,item["year"])

    elif info['title']: # and item['dbtype'] == 'movie':
        type_search='movie'
        temp_query = info['title'] # was item['title'] for get_TMDB_data_filtered, and 'query' for filename
        year = item["year"]
        if int(year) > 0:
            url = "https://api.tmdb.org/3/search/%s?api_key=%s&query=%s&year=%s&language=en"%(type_search,tmdbKey,quote(temp_query),year)
        else:
            url = "https://api.tmdb.org/3/search/%s?api_key=%s&query=%s&language=en"%(type_search,tmdbKey,quote(temp_query))

    filename = 'subs.search.tmdb.%s.%s.%s.json'%(type_search,lowercase_with_underscores(temp_query),year)
    #json_results = get_TMDB_data_popularity_and_votes_sorted(url,filename)

    json_results = get_TMDB_data_filtered(url,filename,temp_query,type_search,year)

    try:
        tmdb_id = int(json_results[0]["id"])
    except Exception as e:
        log("searchForIMDBID (%s_1) Error: [%s]" % (type_search,e))
        tmdb_id = ''
        pass
        # return "0"

    if tmdb_id == '':
        if item['imdb_id'] != '':
            tmdb_id = item['imdb_id']
        else:
            return "0"

    filename = 'subs.search.tmdb.fulldata.%s.%s.json'%(type_search,tmdb_id)
    url = "https://api.tmdb.org/3/%s/%s?api_key=%s&language=en&append_to_response=external_ids"%(type_search,tmdb_id,tmdbKey)
    #url = "https://api.themoviedb.org/3/%s/%s?api_key=%s&language=en-US&append_to_response=external_ids"%(type_search,tmdb_id,tmdbKey)
    log("searchTMDB fulldata id: %s" % url)

    json = caching_json(filename,url)

    try:
        imdb_id = json['external_ids']["imdb_id"]
    except Exception as e:
        log("searchForIMDBID (%s_2) Error: [%s]" % (type_search,e))
        return "0"

    return imdb_id

'''
def Caching(filename,url):
    import requests

    try:
      x=requests.get(url).json()
    except:
      x={}
      pass
    return x
'''

def get_now_played():
    """
    Get info about the currently played file via JSON-RPC

    :return: currently played item's data
    :rtype: dict
    """
    request = json.dumps({
        'jsonrpc': '2.0',
        'method': 'Player.GetItem',
        'params': {
            'playerid': 1,
            'properties': ['showtitle', 'season', 'episode']
         },
        'id': '1'
    })
    item = json.loads(xbmc.executeJSONRPC(request))['result']['item']
    item['file'] = xbmc.Player().getPlayingFile()  # It provides more correct result
    return item

def get_more_data(filename):
    title, year = xbmc.getCleanMovieTitle(filename)
    log("CleanMovieTitle: title - %s, year - %s " %(title, year))
    tvshow=' '
    season=0
    episode=0
    try:
        yearval = int(year)
    except ValueError:
        yearval = 0

    patterns = [
                '\WS(?P<season>\d\d)E(?P<episode>\d\d)',
                '\W(?P<season1>\d)x(?P<episode1>\d\d)'
                ]

    for pattern in patterns:
        pattern = r'%s' % pattern
        match = re.search(pattern, filename, flags=re.IGNORECASE)
        log("regex match: " + repr(match))

        if match is None:
            continue
        else:
            title = title[:match.start('season') - 1].strip()
            season = match.group('season').lstrip('0')
            episode = match.group('episode').lstrip('0')
            log("regex parse: title = %s , season = %s, episode = %s " %(title,season,episode))
            return title,yearval,season,episode

    return title,yearval,season,episode

def is_local_file_tvshow(item):
    return item["title"] and item["year"]==0

def lowercase_with_underscores(_str):   ####### burekas
    return unicodedata.normalize('NFKD', _str).encode('utf-8','ignore').decode('utf-8')
    #return normalize('NFKD', str(str(str, 'utf-8'))).encode('utf-8', 'ignore')